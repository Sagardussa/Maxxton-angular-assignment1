import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-notapage',
  templateUrl: './notapage.component.html',
  styleUrls: ['./notapage.component.css']
})
export class NotapageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
