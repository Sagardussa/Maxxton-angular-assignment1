import { EnddatePipe } from './enddate.pipe';

describe('EnddatePipe', () => {
  it('create an instance', () => {
    const pipe = new EnddatePipe();
    expect(pipe).toBeTruthy();
  });
});
