import { Employeeclass } from './employeeclass';

describe('Employeeclass', () => {
  it('should create an instance', () => {
    expect(new Employeeclass()).toBeTruthy();
  });
});
