import { ValidationruleDirective } from './validationrule.directive';

describe('ValidationruleDirective', () => {
  it('should create an instance', () => {
    const directive = new ValidationruleDirective();
    expect(directive).toBeTruthy();
  });
});
